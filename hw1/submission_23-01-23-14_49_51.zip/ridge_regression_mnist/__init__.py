from . import ridge_regression

__all__ = ["ridge_regression"]
